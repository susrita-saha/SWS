
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.Random;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/setNewPassword"})
public class setNewPassword extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
             String host ="smtp.gmail.com";
String email=request.getParameter("email");
String username ="humane.sws@gmail.com"; // your username
String fromname = "humane.sws@gmail.com" ;//email id
String password="humane@123" ;//your password
String protocol = "smtp";
String to_addr =email;
String aToZ="ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789"; // 36 letter.
String randomStr=generateRandom(aToZ);

String str="";
try {
Properties props = System.getProperties();
//props.put("mail.smtp.starttls.enable", "true");

props.put("mail.smtp.host", host);
props.put("mail.smtp.auth", "true");
props.put("mail.smtp.from", fromname);
props.put("mail.smtp.starttls.enable", "true");
props.put("mail.smtp.socketFactory.port","587");
props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
props.put("mail.smtp.socketFactory.fallback", "false");

Session s = Session.getDefaultInstance(props, null);
s.setDebug(true);

MimeMessage message = new MimeMessage(s);
InternetAddress from = new InternetAddress(fromname);
message.setFrom(from);
InternetAddress to = new InternetAddress(to_addr);
message.addRecipient(Message.RecipientType.TO, to);
message.setSubject("One Time Password");
message.setText("Your one time password is "+randomStr);
message.saveChanges();
Transport transport = s.getTransport(protocol);
transport.connect(host, username, password);
transport.sendMessage(message, message.getAllRecipients());
transport.close();
HttpSession session=request.getSession();  
session.setAttribute("email_id", email);
session.setAttribute("random", randomStr);
RequestDispatcher req=request.getRequestDispatcher("setnewpassword.jsp");
req.forward(request, response);
}
catch(Exception e)
{ out.println(e);}

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
private static String generateRandom(String aToZ) {
    Random rand=new Random();
    StringBuilder res=new StringBuilder();
    for (int i = 0; i < 17; i++) {
       int randIndex=rand.nextInt(aToZ.length()); 
       res.append(aToZ.charAt(randIndex));            
    }
    return res.toString();
}
}


