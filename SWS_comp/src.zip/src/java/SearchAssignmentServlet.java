/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/SearchAssignmentServlet"})
public class SearchAssignmentServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            response.setContentType("text/html");
            HttpSession sess=request.getSession(true);
        
            String htmlcode="";
            String assignment_id = request.getParameter("assignment_id");
            //String sqlquery = "select * from assignment where assignment_id=?";
            String sqlquery="select  a.assignment_id,a.assignment_name,a.details,a.team_id,a.site,a.amount,a.allocation_date,a.service,"
       +" t.entry_date,t.progress_text,t.complete_status,t.viewed_by_admin,a.approved_by,a.approved_on from assignment a left join" 
+"(select * from teamprogress t2 where t2.teamprogress_id in"
+"(select max(t1.teamprogress_id) from teamprogress t1 group by t1.assignment_id)) t on a.assignment_id=t.assignment_id where a.assignment_id="+assignment_id;//String sqlquery1 = "select * from team where team_id not in(select team_id from assignment)";;
            String sqlquery1="select t1.team_id,t1.team_name,t1.team_leader_id,m.name,t1.member_count from team t1 join member m "
                      + "on t1.team_leader_id=m.mem_id"
+" where not exists ("
+"select a.assignment_id from assignment a "
            + "where a.team_id=t1.team_id and a.assignment_id not in "
            + "(select a1.assignment_id from assignment a1 join teamprogress t "
            + "on a1.assignment_id=t.assignment_id "
            + "where a1.team_id=a.team_id and "
            + "t.complete_status in ('yes','cnc')))";
            String sqlquery2;
            int fund=0;
            ResultSet rs2=null; 
    ResultSet rs=null;
    ResultSet rs1=null;
            try{
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "user");
            
    PreparedStatement ps1=con.prepareStatement(sqlquery);
          //  ps1.setString(1, assignment_id);
              
        rs = ps1.executeQuery();
        
       PreparedStatement ps2=con.prepareStatement(sqlquery1,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
           
              
        rs1 = ps2.executeQuery();
    sqlquery2="select * from fund";
               PreparedStatement stmt1=con.prepareStatement(sqlquery2);
               rs2 = stmt1.executeQuery();
               rs2.next();
               fund=Integer.parseInt(rs2.getString(1));
        
        if (rs.next()){
            String assignment_name = rs.getString(2);
         String details = rs.getString(3);
        String team_id = rs.getString(4);       
        String site = rs.getString(5);
        String amount = rs.getString(6);
        String alloc_date = rs.getString(7);
          String service = rs.getString(8);
          String entry_date = rs.getString(9);
          String progress_text = rs.getString(10);
          String complete_status = rs.getString(11);
          String viewed_by_admin = rs.getString(12);
        String approved_by = rs.getString(13);
        String approved_on = rs.getString(14);
        
       if (amount==null ||  amount.equals("null") || amount.equals("")){
       amount="0";
   }
       
                
                
                htmlcode+= "<form action=\"editassignmentback.jsp\" name=\"frm1\" onsubmit=\"return func1("+fund+",frm1)\">"
  +"<input type=\"hidden\" style=\"width:200px;\" value=\""+assignment_id+"\" name=\"assignment_id\" id=\"assignment_id\" />"      
                        +"<input type=\"hidden\" style=\"width:200px;\" value=\""+team_id+"\" name=\"old_team_id\" id=\"old_team_id\" />"      
                        +"<input type=\"hidden\" style=\"width:200px;\" value=\""+amount+"\" name=\"old_amount\" id=\"old_amount\" />"      
      +"<table><tr><td> <label><b>Assignment Name:</b></label></td>"
    +"<td><input type=\"text\" style=\"width:200px;\"  name=\"assignment_name\" id=\"assignment_name\" value=\""+assignment_name+"\" required/></td></tr>"
        +"<tr><td><label><b>Amount allocated:</b></label></td>"
    +"<td><input type=\"text\" style=\"width:200px;\"  name=\"amount\" id=\"amount\"  value=\""+amount+"\" required onfocus=\"document.getElementById('messageTd1').innerHTML='Available Allocatable Fund (in Rs): "+(fund-3000)+"';\" onblur=\"document.getElementById('messageTd1').innerHTML='';\"/>"
                        + "<div id=\"messageTd1\" style=\"color:red\"></div></td></tr>"
     +"<tr><td><label><b>Assignment Details</b></label></td>"
    +"<td><textarea style=\"width:200px;\" rows=\"5\"  name=\"details\" id=\"details\" required >"+details+"</textarea><br/><br/></td></tr>"
     +"<tr><td><label><b>Team ID:</b></label></td>"
    +"<td><input type=\"text\" style=\"width:200px;\"  name=\"team_id\" id=\"team_id\"  value=\""+team_id+"\" onfocus=\"document.getElementById('show-on-focus').style.display='block';\" onblur=\"document.getElementById('show-on-focus').style.display='none';\" required/></td></tr>"
    +" <tr><td class=\"cell\" colspan='2'>"
     + "<div  id=\"show-on-focus\" style='display:none'>"
              +"<h2>Available Teams</h2>"
                 +" <link href='css/infoTable.css' rel='stylesheet'/>"
                 +"<div id='tablecontainer' style=\"height:800px;\">"
              +"<table style=\"width:100%;margin:auto;border-collapse:collapse;empty-cells:hide\">"
                 + "<tr>";
        if(rs1.next()==false)
        {
            htmlcode=htmlcode      
              +"<td align='center'>No available team</td></tr>";
        }  
        else
        {
             rs1.beforeFirst();
         
                 
              htmlcode+="<th><label><b>Team ID</b></label><th>"          
              +"<th><label><b>Team Name</b></label><th>"
                      +"<th>Team Leader ID</th>"
+"<th>Team Leader Name</th>"
+"<th>Member Count</th>"
              +"</tr>";
       while(rs1.next())
       {
          htmlcode=htmlcode 
              +"<tr>"
              +"<td align='center'>"+rs1.getString(1)+"<td>"
              +"<td align='center'>"+rs1.getString(2)+"<td>"
              +"<td align='center'>"+rs1.getString(3)+"<td>"
              +"<td align='center'>"+rs1.getString(4)+"<td>"
              +"<td align='center'>"+rs1.getString(5)+"<td>"
              +"</tr>";
       }
             
        }        
                 htmlcode+="</table><br/></div></div></td></tr>"
     +"<tr><td><label><b>Site:</b></label></td>"
    +"<td><input type=\"text\" style=\"width:200px;\"  name=\"site\" id=\"site\"  value=\""+site+"\" required/></td></tr>"                      
    +"<tr><td><label><b>Allocation Date:</b></label></td><td>"+alloc_date+"</td></tr>"
     +"<tr><td><label><b>Most Recent Team Progress:</b></label></td><td>"+progress_text+"</td></tr>"
                        +"<tr><td><label><b>Completion Status:</b></label></td><td>"+complete_status+"</td></tr>"
                        +"<tr><td><label><b>Viewed By Admin:</b></label></td><td>"+viewed_by_admin+"</td></tr>"
      +"<tr><td><label><b>Approved by:</b></label></td><td>"+approved_by+"</td></tr>"
     +"<tr><td><label><b>Approved on:</b></label></td><td>"+approved_on+"</td></tr>"
     +"<tr><td><label><b>Service:</b></label></td><td>"+service+"</td></tr></table>"
            
      +"<div class=\"clearfix\"><button type=\"submit\" class=\"createassignment\">ok</button>"
      +"<button type=\"reset\"  class=\"resetbtn\">cancel</button></div></form>"; 
                 
               
            }
            else{
                htmlcode="Assignment does not exist! <br/>Please check whether correct Assignment Id has been entered and try again.";
            }
            
            }catch(Exception e){
                htmlcode=e.getMessage();
            }
            finally{
                out.println(htmlcode);
                
            }
            
        }
            
                    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
