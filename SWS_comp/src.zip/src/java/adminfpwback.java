

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(urlPatterns = {"/adminfpwback"})
public class adminfpwback extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
Connection con= null;
PreparedStatement ps = null,ps1=null;
ResultSet rs = null,rs1=null;
int updatequery=0;
String message="";

String email = request.getParameter("email");
String otp = request.getParameter("otp");
String psw = request.getParameter("psw");
HttpSession session=request.getSession();  
String email1=(String)session.getAttribute("email_id");
String otp1=(String)session.getAttribute("random");
String sql="select * from admin where email=?";
String sqlquery="update admin set password=? where email=?";
try
{
    Class.forName("oracle.jdbc.OracleDriver");
    con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","user");
    ps1=con.prepareStatement(sql);
    ps1.setString(1,email);
    rs1=ps1.executeQuery();
     if(rs1.next() && email.equals(email1) && otp.equals(otp1)) 
   {
       String passwordEnc = AESencrp.encrypt(psw);
       ps = con.prepareStatement(sqlquery);
       ps.setString(1, passwordEnc);
       ps.setString(2, email);
       updatequery=ps.executeUpdate();
       message="Password changed successfully";
   }
   else
   {
       message="Please enter correct email id and otp";
   }
}
catch(Exception sqe)
{
    message="Password Updation Failed! Please Try Again.";
}
finally
{
     request.setAttribute("msg", message);
                       RequestDispatcher req=request.getRequestDispatcher("success.jsp");
                       req.forward(request, response);

}

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
