/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/SearchTeamServlet"})
public class SearchTeamServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            response.setContentType("text/html");
            String htmlcode="";
            String team_id = request.getParameter("team_id");
            String sqlquery1 = "select * from team where team_id=?";
            String sqlquery2 = "select * from teamform inner join member on teamform.member_id=member.mem_id where team_id=?";
            String sqlquery3 = "select * from member where available='yes'";


    ResultSet rs1=null;
    ResultSet rs2=null;
    ResultSet rs3=null;
    ResultSet rs4=null;

            try{
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "user");
            
            PreparedStatement ps1=con.prepareStatement(sqlquery1);
            ps1.setString(1, team_id);
            rs1 = ps1.executeQuery();
            
        PreparedStatement ps2=con.prepareStatement(sqlquery2,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ps2.setString(1, team_id);             
        rs2 = ps2.executeQuery();
        
        PreparedStatement ps3=con.prepareStatement(sqlquery3,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);     
        rs3 = ps3.executeQuery();
        
        PreparedStatement ps4=con.prepareStatement(sqlquery2,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ps4.setString(1, team_id);             
        rs4 = ps4.executeQuery();
        /*String name = rs1.getString(2);
        String email = rs1.getString(3);
        String password = rs1.getString(4);
        String phone = rs1.getString(2);*/
        
        if (rs1.next()){
            
        String team_name = rs1.getString(2);
        String team_leader = rs1.getString(3);
        String member_count = rs1.getString(4);
        
        //while(rs2.next())
        //{   
        //String member_id = rs2.getString(2);
        
        
        //htmlcode="<link href='css/infoTable.css' rel='stylesheet'/>";
                
                htmlcode+= "<form action=\"editTeamback.jsp\" name=\"frm1\" onsubmit=\"return func1()\">" 
                  
  +"<input type=\"hidden\" style=\"width:200px;\" value=\""+team_id+"\" name=\"team_id\" id=\"team_id\" />" 
             +"<table border='0' cellspacing='10' align='center' style=\"margin:auto;\"><tr><td><label><b>Team Name:</b></label></td><td>"+team_name+"</td></tr>"
     +"<tr><td><label><b>Team Leader ID:</b></label></td><td>"+team_leader+"</td></tr>"
      +"<tr><td><label><b>Member Count:</b></label></td><td>"+member_count+"</td></tr>"
              +"<br/><br/>"
              +"<h2>Team members</h2>";
              if(rs2.next()==false)
              {
                  htmlcode=htmlcode+
                   "<td align='center'>No Team Member Yet!</td>";
              }  
              else
              { 
               rs2.beforeFirst();
               htmlcode=htmlcode
              +"<tr>"
              +"<th><label><b>Member ID</b></label></th>"          
              +"<th><label><b>Name</b></label></th>"
              +"<th><label><b>Email ID</b></label></th>"
              +"<th><label><b>Password</b></label></th>"
              +"<th><label><b>Phone No</b></label></th>"
              +"<th><label><b>Age</b></label></th>"
              +"<th><label><b>Sex</b></label></th>"
              +"<th><label><b>Available</b></label></th>"
              +"<th><label><b>Member Type</b></label></th>"
              +"</tr></table>"
              +"<br/><br/>";
       while(rs2.next()){
           
      htmlcode=htmlcode 
              +"<table><tr>"
              +"<td>"+rs2.getString(2)+"<td>"
              +"<td>"+rs2.getString(4)+"<td>"
              +"<td>"+rs2.getString(5)+"</td>"
              +"<td>"+rs2.getString(6)+"<td>"
              +"<td>"+rs2.getString(7)+"</td>"
              +"<td>"+rs2.getString(8)+"<td>"
              +"<td>"+rs2.getString(9)+"</td>"
              +"<td>"+rs2.getString(10)+"<td>"
              +"<td>"+rs2.getString(11)+"</td>"
              +"</tr></table>";

              }
           }
        htmlcode=htmlcode
              +"<h2>Add Members</h2>"
           //     +"<link href='css/infoTable.css' rel='stylesheet'/>"
              +"<div id='tablecontainer' style=\"height:150px;\">";
                if(rs3.next()==false)
                {
                   htmlcode=htmlcode
                   + "<td align='center'>No member available</td>"; 
                }
                else
                { 
                    rs3.beforeFirst();
                  htmlcode=htmlcode                
              +"<table border='0' cellspacing='10' align='center' style=\"margin:auto;\"><tr>"
              +"<th>Add</td>"
              +"<th><label><b>Member ID</b></label></th>"          
              +"<th><label><b>Name</b></label></th>"
              +"<th><label><b>Email ID</b></label></th>"
              +"<th><label><b>Password</b></label></th>"
              +"<th><label><b>Phone No</b></label></th>"
              +"<th><label><b>Age</b></label></th>"
              +"<th><label><b>Sex</b></label></th>"
              +"<th><label><b>Available</b></label></th>"
              +"<th><label><b>Member Type</b></label></th>"
              +"</tr></table>"
              +"<br/><br/>";
                  
       while(rs3.next())
       {
          htmlcode=htmlcode 
              +"<table><tr>"
              +"<td><input type=\"checkbox\"  name=\"check\" id=\"check\" value=\""+rs3.getString(1)+"\"/><td>"
              +"<td align='center'>"+rs3.getString(1)+"<td>"
              +"<td>"+rs3.getString(2)+"<td>"
              +"<td>"+rs3.getString(3)+"</td>"
              +"<td>"+rs3.getString(4)+"<td>"
              +"<td>"+rs3.getString(5)+"</td>"
              +"<td>"+rs3.getString(6)+"<td>"
              +"<td>"+rs3.getString(7)+"</td>"
              +"<td>"+rs3.getString(8)+"<td>"
              +"<td>"+rs3.getString(9)+"</td>"
              +"</tr></table>";
       }
                        
                           
      htmlcode=htmlcode+"<div class=\"clearfix\"><button type=\"submit\" class=\"createteam\">ok</button>"
      +"</div></form>"; 
                }
      htmlcode=htmlcode+"<form action=\"deleteMember.jsp\" name=\"frm1\" onsubmit=\"return func1()\">"
              +"<input type=\"hidden\" style=\"width:200px;\" value=\""+team_id+"\" name=\"team_id1\" id=\"team_id1\" />"
              +"<input type=\"hidden\" style=\"width:200px;\" value=\""+team_leader+"\" name=\"team_leader\" id=\"team_leader\" />"
              +"<h2>Delete Members</h2>"
              +"<table><tr>"
              +"<th>Delete</th>"
              +"<th><label><b>Member ID</b></label></th>"          
              +"<th><label><b>Name</b></label></th>"
              +"<th><label><b>Email ID</b></label></th>"
              +"<th><label><b>Password</b></label></th>"
              +"<th><label><b>Phone No</b></label></th>"
              +"<th><label><b>Age</b></label></th>"
              +"<th><label><b>Sex</b></label></th>"
              +"<th><label><b>Available</b></label></th>"
              +"<th><label><b>Member Type</b></label></th>"
              +"</tr></table>"
              +"<br/><br/>"; 
      rs2.beforeFirst();
       while(rs2.next()){
           
      htmlcode=htmlcode 
              +"<table><tr>"
              +"<td><input type=\"checkbox\"  name=\"check\" id=\"check\" value=\""+rs2.getString(2)+"\"/><td>"
              +"<td>"+rs2.getString(2)+"<td>"
              +"<td>"+rs2.getString(4)+"<td>"
              +"<td>"+rs2.getString(5)+"</td>"
              +"<td>"+rs2.getString(6)+"<td>"
              +"<td>"+rs2.getString(7)+"</td>"
              +"<td>"+rs2.getString(8)+"<td>"
              +"<td>"+rs2.getString(9)+"</td>"
              +"<td>"+rs2.getString(10)+"<td>"
              +"<td>"+rs2.getString(11)+"</td>"
              +"</tr></table>"
              +"</div>";

              }
     htmlcode=htmlcode+"<div class=\"clearfix\"><button type=\"submit\" class=\"createteam\">Delete</button>"
      +"</div></form>";
      
      
        //}
            }
            else{
                htmlcode="Team does not exist! <br/>Please check whether correct Team Id has been entered and try again.";
            }
            
            }catch(Exception e){
                htmlcode=e.getMessage();
            }
            finally{
                out.println(htmlcode);
                
            }
            
        }
            
                    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
