

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/acceptRequest"})
public class acceptRequest extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Connection con=null;
    PreparedStatement ps1 = null, ps2 = null,ps3=null,ps4=null;
    ResultSet rs = null;
    String username="";
    String password="";
   String message="";
   int updateQuery=0;
   String[] check=request.getParameterValues("check");
   
   
    String sql1 = "select * from admin_temp where admin_temp_id=?";
    String sql2 = "insert into admin(email,username,password,phone,address,date_of_birth,sex,qualifications,name) VALUES (?, ?, ?,?, ?, ?,?,?,?)";
    String sql3="delete from admin_temp where admin_temp_id=?";

 try {
                            
         Class.forName("oracle.jdbc.OracleDriver");
         con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","user");
        
        for(int i=0;i<check.length;i++)
        {
          ps1 = con.prepareStatement(sql1);
          ps1.setString(1,check[i] );
          rs=ps1.executeQuery();
          rs.next();
          username=rs.getString(3);
          password=rs.getString(4);
          String usernameEnc = AESencrp.encrypt(username);
          String passwordEnc = AESencrp.encrypt(password);
          ps2 = con.prepareStatement(sql2);
          ps2.setString(1, rs.getString(2));
          ps2.setString(2, usernameEnc);
          ps2.setString(3, passwordEnc);
          ps2.setString(4, rs.getString(5));
          ps2.setString(5, rs.getString(6));
          ps2.setDate(6, rs.getDate(7));
          ps2.setString(7, rs.getString(8));
          ps2.setString(8, rs.getString(9));
          ps2.setString(9, rs.getString(10));
          updateQuery=ps2.executeUpdate();
          ps3 = con.prepareStatement(sql3);
          ps3.setString(1,check[i] );
          ps3.executeUpdate();
        }

          if(updateQuery!=0)
          {
             message = "Registration Requests have been accepted successfully!";
          }
             }
            catch (Exception ex) {
            message = "Request Acceptance Failed! Please try again."+ex.getMessage();
   
               }
        finally
         {
            request.setAttribute("msg", message);
        RequestDispatcher req = request.getRequestDispatcher("success.jsp");
        req.forward(request, response);
       
        
         }  
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
