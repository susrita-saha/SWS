
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet(urlPatterns = {"/adminregback"})
public class adminregback extends HttpServlet {

 
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           Connection con=null;
    PreparedStatement ps1 = null, ps2 = null,ps3=null,ps4=null;
    ResultSet rs = null,rs1=null;
    
   String message="";
   int updateQuery=0,flag=0;
   String username="",password="",usernameDec="",passwordDec="";
   String name=request.getParameter("name");
   String email=request.getParameter("email");
   String uname=request.getParameter("uname");
   String psw=request.getParameter("psw");
   String phone=request.getParameter("ph_num");
   String address=request.getParameter("address");
   String dob=request.getParameter("dob");
   String sex=request.getParameter("sex");
   String qualify=request.getParameter("qualify");
   
   
   
     String sql1 = "select * from admin where email=?";
    String sql2 = "insert into admin_temp(name,email,username,password,phone,address,date_of_birth,sex,qualifications) VALUES (?, ?, ?,?, ?, ?,?,?,?)";
    String sql3="select * from admin_temp where email=? and username=? and password=?";
    try {
                            
        java.sql.Date sqlDate=null;
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date parsed = format.parse(dob);
        sqlDate = new java.sql.Date(parsed.getTime());
         Class.forName("oracle.jdbc.OracleDriver");
         con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","user");
        ps1 = con.prepareStatement(sql1);
        ps1.setString(1, email);
        rs = ps1.executeQuery();
        
        while (rs.next())
        {
            username=rs.getString(4);
            password=rs.getString(5);
            usernameDec = AESencrp.decrypt(username);
            passwordDec = AESencrp.decrypt(password);
            if(uname.equals(usernameDec) && psw.equals(passwordDec))
            {    
              message="Admin already exists! Admin ID = " + rs.getString(1);
              flag=1;
              break;
            }
        }    
             if(flag==0)
             {   
              ps2 = con.prepareStatement(sql2);
              ps2.setString(1, name);
              ps2.setString(2, email);
              ps2.setString(3, uname);
              ps2.setString(4, psw);
              ps2.setString(5, phone);
              ps2.setString(6, address);
              ps2.setDate(7, sqlDate);
              ps2.setString(8, sex);
              ps2.setString(9, qualify);
              updateQuery=ps2.executeUpdate();
             }
           if(updateQuery!=0)
           {
              ps3 = con.prepareStatement(sql3);
              ps3.setString(1, email);
              ps3.setString(2, uname);
              ps3.setString(3, psw);
              rs1=ps3.executeQuery();
              rs1.next();
              message = "Registration Request has been sent successfully!Admin Temp ID="+rs1.getString(1);
           }
             }
            catch (Exception ex) {
            message = "Registration request Failed! Please try again.";
   
               }
        finally
         {
            request.setAttribute("msg", message);
        RequestDispatcher req = request.getRequestDispatcher("success.jsp");
        req.forward(request, response);
        
         }  
    
    
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
