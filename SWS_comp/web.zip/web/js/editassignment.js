/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function(){
    
    $("#searchassignment").click(function(){
        
           if (func2()) {
               
               $.post("SearchAssignmentServlet",{"assignment_id":$("#assignment_id").val()},function(htmlcode){
                  
                 $("#messageTd").html("<br/>"+htmlcode);  
           
        });
        
           }
        
        
    });
   
});


    function func2()
{
    
    
        if(isNaN(document.getElementById("assignment_id").value))
    {
        alert("Assignment id should  be numeric");
        document.frm1.assignment_id.focus();
        return false;
        
    }
   if (document.getElementById("assignment_id").value===""){
       alert("Assignment ID field is empty!");
       return false;
   }
        return true;
}
function func3()
{
        document.getElementById("messageTd").innerHTML="";
    
        
}




