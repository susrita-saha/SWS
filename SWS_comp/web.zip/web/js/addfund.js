       /*
$(document).ready(function(){
    
    $("#searchsponsor").click(function(){
        
           if (func2()) {
               
               $.post("SearchFundServlet",{"sponsor_id":$("#sponsor_id").val()},function(htmlcode){
                   $("#messageTd").html("<br/>"+htmlcode);  
        });
           }
    });
});*/

function func2()
{
    alert("hi");
       /* if(isNaN(document.getElementById("sponsor_id").value))
    {
        alert("sponsor id should  be numeric");
        document.getElementById("sponsor_id").focus();
        return false;
    }*/
    if(document.getElementById("fund_donated").value==="0")
    {
        alert("No Donation Entered!");
        document.getElementById("fund_donated").focus();
        return false;
    }
        if(isNaN(document.frm1.fund_donated.value))
    {
        alert("donation should  be numeric");
        document.frm1.fund_donated.focus();
        return false;
    }
    return true;
}
/*function func3(){
        document.getElementById("messageTd").innerHTML="";       
}
*/