/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function func1()
{
    
    if(!isNaN(document.frm1.name.value))
    {
        alert("name field should not be numeric");
        document.frm1.name.focus();
        return false;
    }
    if(isNaN(document.frm1.ph_num.value))
    {
        alert("phone number should  be numeric");
        document.frm1.ph_num.focus();
        return false;
    }
    if(document.frm1.ph_num.value.length<10)
    {
        alert("phone number must be 10 digit");
        document.frm1.ph_num.focus();
        return false;
    }
    if(document.frm1.age.value>100)
    {
        alert("invalid age");
        document.frm1.ph_num.focus();
        return false;
    }
    alert(!document.getElementById("male").checked && !document.getElementById("female").checked);        
    if(!document.getElementById("male").checked && !document.getElementById("female").checked)
    {
        alert("Select Sex");        
        return false;
    }
    return true;
}
function func3()
{
    var psw=document.getElementById("psw").value;
    var len=psw.length;
    if(len<5)
        document.getElementById("pass").innerHTML="<font color=red>weak</font>";
    else if(len<8)
        document.getElementById("pass").innerHTML="<font color=blue>medium</font>";
    else
        document.getElementById("pass").innerHTML="<font color=green><b>strong<b></font>";
}

/*function func3()
{
    var psw=document.getElementById("psw").value;
    var len=psw.length;
    var len1=psw-repeat.length;
    if(len!==len1)
       alert("missmatched password");
            
}*/


