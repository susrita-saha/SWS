
$(document).ready(function(){
    
    $("#searchteam").click(function(){
        
           if (func2()) {
               
               $.post("SearchTeamServlet",{"team_id":$("#team_id").val()},function(htmlcode){
                   
                 $("#messageTd").html("<br/>"+htmlcode);  
           
        });
        
           }
        
        
    });
   
});


    function func2()
{
    
    
        if(isNaN(document.getElementById("team_id").value))
    {
        alert("Team id should  be numeric");
        document.frm1.team_id.focus();
        return false;
        
    }
   if (document.getElementById("team_id").value===""){
       alert("Team ID field is empty!");
       return false;
   }
        return true;
}
function func3()
{
        document.getElementById("messageTd").innerHTML="";
    
        
}
function func4()
{
    
}





