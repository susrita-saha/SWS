function func1()
{
    
    if(!isNaN(document.frm1.teamname.value))
    {
        alert(" team name field should not be numeric");
        document.frm1.teamname.focus();
        return false;
    }
    if(isNaN(document.frm1.no_numbers.value))
    {
        alert("no of members should  be numeric");
        document.frm1.no_numbers.focus();
        return false;
    }
    if(document.frm1.no_numbers.value.length<=10)
    {
        alert("no of team members must be 10");
        document.frm1.no_numbers.focus();
        return false;
    }
    if(isNaN(document.frm1.team_leader_id.value))
    {
        alert("team-leader ID should  be numeric");
        document.frm1.team_leader_id.focus();
        return false;
    }
    
    
    
}