/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

(function () {
    var fileuploads = document.getElementById("fileuploads"),
            baseRow = document.getElementById("baseRow").cloneNode(true);

  //  var i = 0;
    document.getElementById("addmore").addEventListener("click", addClone);

    function addClone() {
        var copy = baseRow.cloneNode(true);
      /*  i = i + 1;
        copy.setAttribute("id", baseRow.getAttribute("id") + i);
        copy.setAttribute("name", baseRow.getAttribute("name") + i);
        var fieldimg = copy.getElementsByTagName('img')[0];
        fieldimg.setAttribute("id", fieldimg.getAttribute("id") + i);
        fieldimg.setAttribute("name", fieldimg.getAttribute("name") + i);
        var fieldfile = copy.getElementsByTagName('input')[0];
        fieldfile.setAttribute("id", fieldfile.getAttribute("id") + i);
        fieldfile.setAttribute("name", fieldfile.getAttribute("name") + i);
        var fieldtext = copy.getElementsByTagName('textarea')[0];
        fieldtext.setAttribute("id", fieldtext.getAttribute("id") + i);
        fieldtext.setAttribute("name", fieldtext.getAttribute("name") + i);*/

        fileuploads.appendChild(copy);
        //  $(".content").css("height","");
    }
   


}());


 
function dothat(th) {
    
    var i = th.parentNode.parentNode.rowIndex;
    document.getElementById('fileuploads').rows[i].cells[1].getElementsByTagName('img')[0].src = window.URL.createObjectURL(th.files[0]);
    document.getElementById('fileuploads').rows[i].cells[2].getElementsByTagName('textarea')[0].disabled = false;
    
}
/*function dothat1(i, th) {
   
   // if (i === 0) {       
   //    document.getElementById('ai_upload').src = window.URL.createObjectURL(th.files[0]);
  //   } else
  //     document.getElementById('ai_upload' + i).src = window.URL.createObjectURL(th.files[0]);
    //table.rows[rowIndex].cells[colIndex].getElementsByTagName('input')[0];
         
       document.getElementById('fileuploads').rows[i].cells[1].getElementsByTagName('img')[0].src = window.URL.createObjectURL(th.files[0]);
     
  }*/
  

