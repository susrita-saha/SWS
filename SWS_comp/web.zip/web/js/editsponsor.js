function func1()
{
    /*    if(isNaN(document.frm1.sponsor_id.value))
    {
        alert("sponsor id should  be numeric");
        document.frm1.sponsor_id.focus();
        return false;
    }*/
    if (ValidateEmail(document.getElementById("sponsor_email").value)){
        document.getElementById("pass2").innerHTML=""; 
    }
    else{
        document.getElementById("pass2").innerHTML="Invalid email address!";
return false;
    }
    if(!isNaN(document.frm1.sponsor_name.value))
    {
        alert("sponsor name field should not be numeric");
        document.frm1.sponsor_name.focus();
        return false;
    }
    if(isNaN(document.frm1.sponsor_ph_num.value))
    {
        alert("phone number should  be numeric");
        document.frm1.ph_num.focus();
        return false;
    }
    if(document.frm1.sponsor_ph_num.value.length!==10 )
    {
        alert("phone number must be 10 digit");
        document.frm1.sponsor_ph_num.focus();
        return false;
    }
        if(!isNaN(document.frm1.sponsor_add.value))
    {
        alert("sponsor address field should not be numeric");
        document.frm1.sponsor_add.focus();
        return false;
    }
    /*    if(isNaN(document.frm1.fund.value))
    {
        alert("donation should  be numeric");
        document.frm1.fund.focus();
        return false;
    }*/
 return true;
    
    
}
var pass_strength;
function IsEnoughLength(str,length)
{
    if ((str == null) || isNaN(length))
        return false;
    else if (str.length < length)
        return false;
    return true;
}
function HasMixedCase(passwd)
{
if(passwd.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/))
    return true;
else 
    return false;
}
function HasNumeral(passwd)
{
    if(passwd.match(/[0-9]/))
return true;
    else 
    return false;
}
function HasSpecialChars(passwd)
{
if(passwd.match(/.[!,@,#,$,%,^,&,*,?,_,~]/))
    return true;
else 
    return false;
}
function CheckPasswordStrength(pwd)
{if (IsEnoughLength(pwd,14) && HasMixedCase(pwd) && HasNumeral(pwd) && HasSpecialChars(pwd))
        pass_strength = "<b><font style='color:olive'>Very strong</font></b>";
    else if (IsEnoughLength(pwd,8) && HasMixedCase(pwd) && (HasNumeral(pwd) || HasSpecialChars(pwd)))
        pass_strength = "<b><font style='color:Blue'>Strong</font></b>";
else if (IsEnoughLength(pwd,8) && HasNumeral(pwd))
    pass_strength = "<b><font style='color:Green'>Good</font></b>";
else 
    pass_strength = "<b><font style='color:red'>Weak</font></b>";
document.getElementById('pass').innerHTML = pass_strength;
}

function func2()
{
    var psw=document.getElementById("spsw").value;
    var psw_repeat=document.getElementById("spsw-repeat").value;
    if(!(psw===psw_repeat)){
        document.getElementById("pass1").innerHTML="Password Mismatch";
    document.frm1.psw-repeat.focus();
        }else{
           document.getElementById("pass1").innerHTML=""; 
            
        }
    
}


function ValidateEmail(mail){
if (/^\w+([\.-]?\ w+)*@\w+([\.-]?\ w+)*(\.\w{2,3})+$/.test(mail))
{
//document.getElementById("pass2").innerHTML=""; 
}else{
//document.getElementById("pass2").innerHTML="Invalid email address!";
return false;
}
return true;
}